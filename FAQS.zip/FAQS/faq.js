const opt1=document.getElementById("Option1");
const ans1=document.getElementById("search1");
let arr1=false;    
opt1.addEventListener('click',()=>{
        // console.log(x)
        if(arr1==false)
            ans1.setAttribute("style","display: block");
        else   
            ans1.setAttribute("style","display: none");
        arr1=~arr1;
    })
    const opt2=document.getElementById("Option2");
const ans2=document.getElementById("search2");
let arr2=false;    
opt2.addEventListener('click',()=>{
        // console.log(x)
        if(arr2==false)
            ans2.setAttribute("style","display: block");
        else   
            ans2.setAttribute("style","display: none");
        arr2=~arr2;
    })
    const opt3=document.getElementById("Option3");
const ans3=document.getElementById("search3");
let arr3=false;    
opt3.addEventListener('click',()=>{
        // console.log(x)
        if(arr3==false)
            ans3.setAttribute("style","display: block");
        else   
            ans3.setAttribute("style","display: none");
        arr3=~arr3;
    })
    const opt4=document.getElementById("Option4");
const ans4=document.getElementById("search4");
let arr4=false;    
opt4.addEventListener('click',()=>{
        // console.log(x)
        if(arr4==false)
            ans4.setAttribute("style","display: block");
        else   
            ans4.setAttribute("style","display: none");
        arr4=~arr4;
    })
    const opt5=document.getElementById("Option5");
const ans5=document.getElementById("search5");
let arr5=false;    
opt5.addEventListener('click',()=>{
        // console.log(x)
        if(arr5==false)
            ans5.setAttribute("style","display: block");
        else   
            ans5.setAttribute("style","display: none");
        arr5=~arr5;
    })
    const opt6=document.getElementById("Option6");
const ans6=document.getElementById("search6");
let arr6=false;    
opt6.addEventListener('click',()=>{
        // console.log(x)
        if(arr6==false)
            ans6.setAttribute("style","display: block");
        else   
            ans6.setAttribute("style","display: none");
        arr6=~arr6;
    })